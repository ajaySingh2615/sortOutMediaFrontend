<?php
require '../vendor/autoload.php';

use Cloudinary\Configuration\Configuration;

Configuration::instance([
    'cloud' => [
        'cloud_name' => 'dcrk1fzah', 
        'api_key'    => '739623412262183', 
        'api_secret' => '2gQxCaV5g3ptDJ_FNaJOnVNomvs' 
    ],
    'url' => [
        'secure' => true
    ]
]);
?>